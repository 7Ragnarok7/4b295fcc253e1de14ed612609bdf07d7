import os
import pickle
def fun(name,password):
    safecode = {"username":name,"password":password}
    #unsafecode = pickle.dumps(s)
    with open("users.json","w") as f:
        f.write(str(safecode))
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
    
#Just using JSON for serialization instead of pickles