import os
import pickle
def reverse_fun():
      with open("users.json","r") as f:
          data = f.read()
      
      #d = pickle.loads(data)
      return data

if __name__ == '__main__':
      print(reverse_fun())
      
# Just using JSON for deserialization instead of pickles